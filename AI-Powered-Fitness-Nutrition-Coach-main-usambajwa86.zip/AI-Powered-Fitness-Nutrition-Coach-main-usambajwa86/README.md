# AI-Powered-Fitness-Nutrition-Coach
An interactive web application that leverages the power of AI to generate personalized fitness and meal plans based on user-defined fitness goals and dietary preferences. Using the GPT-2 model from the transformers library, the app provides tailored workout and nutrition advice to help users achieve their health objectives.
